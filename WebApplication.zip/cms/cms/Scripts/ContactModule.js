﻿
var module = angular.module("myModule", []);