﻿module.filter('Status', function () {
    return function (status) {

        switch (status)
        {            
            case true: return "Active";
            case false: return "InActive";

            case "Active": return true;
            case "InActive": return false;
        }

    }

});
