﻿

module.controller("myCtl", function ($scope, $http,$filter)
{

    $scope.EditFlag = -1;    
    GetContactDetail();    
    
    //-----------------------------------------------------New Contact---------------------------------------------------
    $scope.NewContactDetails = function () {

        $scope.EditFlag = 0;
        $scope.editStatus = "true";
        $scope.editFirstName = $scope.editSecondName = $scope.editPhoneNo = $scope.editEmail = "";
        $('#popupHeader').text("New Contact Information");
        $("#myModal").modal('show');
    };

    //-----------------------------------------------------Edit Contact-------------------------------------------------
    $scope.EditContactDetails = function (e)
    {   
        var actualStatus = $filter('Status');

        $scope.EditFlag = 1;
        $scope.editFirstName = e.contact.FirstName;
        $scope.editSecondName = e.contact.LastName;
        $scope.editPhoneNo = e.contact.PhoneNumber;
        $scope.editEmail = e.contact.Email;
        $scope.editStatus = actualStatus(e.contact.Status).toString();  //  e.contact.Status.toString();
        $scope.editId = e.contact.Id;
        $('#popupHeader').text("Edit Contact Information");
        $("#myModal").modal('show');
    };

    //-----------------------------------------------------Delete Contact-------------------------------------------------
    $scope.DeleteContactDetails = function (e)
    {
        $("#confirmModal").modal('show');
        $scope.deleteId = e.contact.Id;
    };


    $scope.ConfirmDeleteContactDetails = function ()
    {
        $http.delete("/api/Contact/" + $scope.deleteId).then(function (data, status, headers, config)
        {           
            GetContactDetail();
            $("#operStatus").html("Records Deleted Sucessfully");
            $("#statusModal").modal('show');
        });        
    }


    
    //-----------------------------------------------------SAVE Contact---------------------------------------------------
    $scope.SaveContactDetails = function ()
    {
                
        if ($("input").hasClass("ng-invalid") === false)
        {
            //---------------------------------------------EDIT--------------------------------------------
            if ($scope.EditFlag == 1) {


                var editContactData = { 'FirstName': $scope.editFirstName, 'LastName': $scope.editSecondName, 'PhoneNumber': $scope.editPhoneNo, 'Email': $scope.editEmail, 'Status': $scope.editStatus };
                $http.put("/api/Contact/" + $scope.editId, editContactData).then(function (data, status, headers, config) {
                    GetContactDetail();
                    $("#operStatus").html("Records Updated Sucessfully");
                    $("#statusModal").modal('show');


                }, function (data, status, headers, config) { alert("Error"); });
            }

                //----------------------------------------------NEW-----------------------------------------------
            else if ($scope.EditFlag == 0) {


                var newContactData = { 'FirstName': $scope.editFirstName, 'LastName': $scope.editSecondName, 'PhoneNumber': $scope.editPhoneNo, 'Email': $scope.editEmail, 'Status': $scope.editStatus };
                $http.post("/api/Contact", newContactData).then(function (data, status, headers, config) {
                    GetContactDetail();
                    $("#operStatus").html("Records Inserted Sucessfully");
                    $("#statusModal").modal('show');


                }, function (data, status, headers, config) { alert("Error"); });
            }
            else {
                alert("Invalid option");
            }

            $("#myModal").modal('hide');
        }
        else { return false; }
    }
           

    //-------------------------------------------------------GET--------------------------------------------------------------
    function GetContactDetail()
    {
        $("#loading").modal("show");

        //------------------------------------------Get Data -----------------------------------------------
        $http.get("/api/Contact").then(function (response)
        {            
            var actualStatus = $filter('Status');            
            $.each(response.data, function (index, value)
            {               
                value.Status = actualStatus(value.Status);
            });

            $("#loading").modal("hide");
            $scope.Contacts = response.data;

        }).catch(function (data) {

            $("#loading").modal("hide");
            alert("error");

        });

    }
});