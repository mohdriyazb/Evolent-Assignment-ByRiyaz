﻿cms-webAplication - 1st July 2018 - Riyaz Mohammed

CONTENTS OF THIS FILE
--------------------- 
 * Introduction
 * Requirements
 * Recommended modules
 * Installation
 * Configuration
 * Troubleshooting
 * Maintainers


INTRODUCTION
------------
This is web application that use to store the contact information in DB . You can perform following operations with stored data
1. Create new Contacts
2. Update existing Contacts
3. Delete Existing Contacts
4. View all the Contacts.

To insert a new Records - click on + icon placed at the end of search bar.
To edit a existing record - select the records and double click
To delete the existing records - click on the trash bin icon.
To Search for specific records - type it in the searchbar.

REQUIREMENTS
------------
*.NET Framework 4.5
*.IIS for deployment of application
*DB setup via ContactDatabasesetup Application


RECOMMENDED MODULES
-------------------
 Due to time constraint , it support single view for all the users. In other words , contacts created by one user is visible to another user.
 We can enhance it with Login details - to support multiple users.So that only logged in user can see and perform different operation on his/her contacts only.


 INSTALLATION
------------
 1. Create a folder under C:\inetpub\wwwroot\ and named it as CMS
 2. Copy the all the content / files from the folder : CMS-WebApplication / Publis
 3. In IIS convert the folder to application by providing proper application pool.

  
 CONFIGURATION
-------------
 Application contain a file named web.Config. App.config contain following section.
  
 <connectionStrings>
    <add name="ContactDbContext" connectionString="Pooling=false;server=ADMIN-PC\SQLEXPRESS;database=Assignment_Riyaz_ContactDb; integrated security = true;" providerName="System.Data.SqlClient"/>  
 </connectionStrings>

 ContactDatabaseSetup(this) Application and SQL Server on SAME Machine
 ---------------------------------------------------------------
 if executing this application on the machine where SQL server is installed (with Windows Authentication enabled)
 NO CHANGES NEEDED in app.config connectionStrings section.

 ContactDatabaseSetup(this) Application and SQL Server on DIFFERENT Machine
 ---------------------------------------------------------------
 if SQL Server is installed on remote machine and this application is executing from another machine.
 Before to perform any changes in connection strings section , following values are needed.

 *server Name or IP address : Server Name / IP Address where SQL Server is installed.
 *User Id : User id with which we can connect to SQL server 
 *Password : Password for the respective User Id.

Replace ConnectionString with the following one and replace the **text** with respective values

<connectionStrings>
 <add name="ContactDbContext" connectionString="Data Source=** Remote Server Name/IP Address **;Initial Catalog=Contact-Prod;Persist Security Info=True;User ID= **UserID**;Password=**Password**" providerName="System.Data.SqlClient"/> 
</connectionStrings>


TROUBLESHOOTING
----------------
In case of issue , application will provide the enough information to resolve it. 
if still issue occur please check the following
1. Getting Ping response from remote server. 
2. localsystem name and ipaddress.
3. check for the installation once again.
4. Check for connection string - it should match with the connection string in ContactDbSetup application.


MAINTAINERS
-----------
Current maintainers:
 * Riyaz Mohammed - mohd.riyazb@gmail.com
 

