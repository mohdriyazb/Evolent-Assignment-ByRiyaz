﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using cms.Models;

namespace cmd
{
    public class ContactDbContext : DbContext
    {
        public DbSet<ContactDetail> Contact { get; set; }
    }
}