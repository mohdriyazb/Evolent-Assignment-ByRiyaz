﻿
using cmd;
using cms.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using log4net;


namespace cms.Controllers
{
    public class ContactController : ApiController
    {
        /// <summary>
        /// get all the contact details
        /// </summary>
        /// <returns>List of contactDetail model</returns>
        public List<ContactDetail> Get()
        {
            try
            {   
               
                ContactDbContext context = new ContactDbContext();

                List<ContactDetail> contactList = new List<ContactDetail>();
                if (context.Contact == null || !context.Contact.Any()) { return contactList; }
                    
                contactList = context.Contact.Select(x => x).ToList();
                return contactList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Put - Edit the exiting data
        /// </summary>
        /// <param name="id">Id of Contact to be updated</param>
        /// <param name="contactData">Data to be edited</param>
        /// <returns>HttpResponsemessage - contain status code and other details</returns>
        public HttpResponseMessage Put(int id, [FromBody] ContactDetail contactData)
        {
            try
            {
                ContactDbContext context = new ContactDbContext();

                var specificContact = context.Contact.FirstOrDefault(x => x.Id == id);
                if (specificContact == null) { return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Contact details for id = " + id + " - Not found"); }

                specificContact.FirstName = contactData.FirstName;
                specificContact.LastName = contactData.LastName;
                specificContact.PhoneNumber = contactData.PhoneNumber;
                specificContact.Status = contactData.Status;
                specificContact.Email = contactData.Email;
                context.SaveChanges();
                return Request.CreateResponse(HttpStatusCode.OK);

            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex);
            }
        }

        /// <summary>
        /// POST - Insert new Contact in Database.
        /// </summary>
        /// <param name="contactData">New Data to be inserted</param>
        /// <returns>HttpResponsemessage - contain status code and other details</returns>
        public HttpResponseMessage Post([FromBody]ContactDetail contactData)
        {
            try
            {
                ContactDbContext context = new ContactDbContext();
                context.Contact.Add(contactData);
                context.SaveChanges();

                var message = Request.CreateResponse(HttpStatusCode.Created, contactData);
                return message;
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex);
            }
        }

        /// <summary>
        /// DELETE : delete existing data from the database.
        /// </summary>
        /// <param name="id">Id to be deleted</param>
        /// <returns>HttpResponsemessage - contain status code and other details</returns>
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                ContactDbContext context = new ContactDbContext();
                if (context.Contact == null || !context.Contact.Any()) { return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Contact details for id = " + id + " - Not found"); }

                var specificContact = context.Contact.FirstOrDefault(x => x.Id == id);

                if (specificContact != null)
                {
                    List<ContactDetail> contactList = new List<ContactDetail>();
                    context.Contact.Remove(specificContact);
                    context.SaveChanges();
                    return Request.CreateResponse(HttpStatusCode.OK);
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Contact details for id = " + id + " - Not found");
                }

            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex);
            }

        }
    }
}
