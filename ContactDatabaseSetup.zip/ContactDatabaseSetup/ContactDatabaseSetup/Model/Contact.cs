﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace ContactDatabaseSetup.Model
{
    public class Contact
    {
        public int Id { get; set; }

        [StringLength(50), Column(TypeName = "varchar")]        
        [Required]
        public string FirstName { get; set; }

        [StringLength(50), Column(TypeName = "varchar")]
        public string LastName { get; set; }

        [StringLength(150), Column(TypeName = "varchar")]
        public string Email { get; set; }

        [StringLength(50), Column(TypeName = "varchar")]
        [Required]
        public string PhoneNumber { get; set; }

         [Required]
        public bool Status { get; set; }        
    }
}
