﻿using System;
using System.Data.Entity;
using System.Linq;
using ContactDatabaseSetup.Context;

namespace ContactDatabaseSetup
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Warning : In App.config, Database given in ConnectionString, will be Dropped and ReCreate.");
                Console.WriteLine();
                Console.Write("Confirm you Decision (Y/ N) :  ");
                var confirm =  Console.ReadLine();

                if (!string.IsNullOrEmpty(confirm) && confirm.ToUpper() == "Y")
                {
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("Starting Initilization of DB and Table");
                    Console.WriteLine("Please Wait , this will take some time......");


                    var contact = new ContactDbContext();
                    Database.SetInitializer<ContactDbContext> (new CustomInitializer<ContactDbContext>());                         
                    var data = contact.Contact.ToList();

                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Completed Initilization of DB and Table.");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Database Initilization Cancelled");
                    Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("Error : Message :  {0} ", ex.Message);

                if (ex.InnerException != null)
                {
                    Console.WriteLine("Error : Inner Exception {0} ", ex.InnerException);
                    Console.WriteLine("Error : Inner Exception Message {0} ", ex.InnerException.Message);
                }
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("Failed Initilization of DB and Table  ");
                Console.ReadLine();
            }



        }
    }
}
