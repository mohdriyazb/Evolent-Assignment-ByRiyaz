﻿using System.Data.Entity;
using ContactDatabaseSetup.Model;
using System.Data.Entity.ModelConfiguration.Conventions;


namespace ContactDatabaseSetup.Context
{
    public class ContactDbContext : DbContext
    {
        public DbSet<Contact> Contact { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            base.OnModelCreating(modelBuilder);
        }

    }
}
