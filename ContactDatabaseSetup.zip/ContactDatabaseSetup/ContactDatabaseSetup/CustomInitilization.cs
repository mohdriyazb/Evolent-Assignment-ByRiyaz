﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using ContactDatabaseSetup.Context;

namespace ContactDatabaseSetup
{
    public class CustomInitializer<T> : DropCreateDatabaseAlways<ContactDbContext>
    {
        protected override void Seed(ContactDbContext context)
        {
            base.Seed(context);
        }

        
    }
}
