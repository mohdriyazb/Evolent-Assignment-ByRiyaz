﻿ContactManagementSystem - 1st July 2018 - Riyaz Mohammed

CONTENTS OF THIS FILE
--------------------- 
 * Introduction
 * Requirements
 * Recommended modules
 * Installation
 * Configuration
 * Troubleshooting
 * Maintainers


INTRODUCTION
------------
This console application is used to create database and respective tables for contact Application.


REQUIREMENTS
------------
*SQL Server - installed on local or remote machine.
*Remote machine Name or IPAddress.
*User Id and Password to access it in case if SQL Server is on remote machine.
*.NET Framework 4.5


RECOMMENDED MODULES
-------------------
 Due to time constraint , it support only creation of one table based on application requirement.
 We can enhance it with Login details - to support multiple users.


 INSTALLATION
------------
 No specific installation needed.
 just execute the application with proper connection string in app.config and Following the step in Console. 


 CONFIGURATION
-------------
 Application contain a file named App.Config. App.config contain following section.
  
 <connectionStrings>
    <add name="ContactDbContext" connectionString="Pooling=false;server=ADMIN-PC\SQLEXPRESS;database=Assignment_Riyaz_ContactDb; integrated security = true;" providerName="System.Data.SqlClient"/>  
 </connectionStrings>

 ContactDatabaseSetup(this) Application and SQL Server on SAME Machine
 ---------------------------------------------------------------
 if executing this application on the machine where SQL server is installed (with Windows Authentication enabled)
 NO CHANGES NEEDED in app.config connectionStrings section.

 ContactDatabaseSetup(this) Application and SQL Server on DIFFERENT Machine
 ---------------------------------------------------------------
 if SQL Server is installed on remote machine and this application is executing from another machine.
 Before to perform any changes in connection strings section , following values are needed.

 *server Name or IP address : Server Name / IP Address where SQL Server is installed.
 *User Id : User id with which we can connect to SQL server 
 *Password : Password for the respective User Id.

Replace ConnectionString with the following one and replace the **text** with respective values

 <connectionStrings>
 <add name="ContactDbContext" connectionString="Data Source=** Remote Server Name/IP Address **;Initial Catalog=Contact-Prod;Persist Security Info=True;User ID= **UserID**;Password=**Password**" providerName="System.Data.SqlClient"/>
 <add name="ContactDbContext" connectionString="Pooling=false;server=ADMIN-PC\SQLEXPRESS;database=Assignment_Riyaz_ContactDb; integrated security = true;" providerName="System.Data.SqlClient"/>  
</connectionStrings>


TROUBLESHOOTING
----------------
In case of issue , application will provide the enough information to resolve it. 
if still issue occur please check the following
1. Getting Ping response from remote server. 
2. localsystem name and ipaddress.


MAINTAINERS
-----------
Current maintainers:
 * Riyaz Mohammed - mohd.riyazb@gmail.com
 

